<!DOCTYPE html>
<html lang="en">
<head>
<title>My web document</title>
<link href="Test.css" rel="stylesheet" type="text/css" />
</head>
<body>
<section id="container">
<p>
Below is a PHP generated message:-
</p>
<?php
include "message.php";
?>
</section>
</body>
</html>
