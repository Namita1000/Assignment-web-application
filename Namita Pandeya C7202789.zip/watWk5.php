<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Processing Input from HTML Forms</h1>
<h2>Login Form using GET</h2>
<form method="" action="">
<fieldset>
<legend>
Login
</legend>
<label for="email">Email: </label>
<input type="text" name="txtEmail"/><br />
<label for="passwd">Password: </label>
<input type="password" name="txtPass" /><br />
<input type="submit" value="Submit" name="loginSubmit" />
<input type="reset" value="Clear" />
</fieldset>
</form>
<?php
if (isset($_POST['loginSubmit'])) {
            if (filter_var($_POST['txtEmail'], FILTER_VALIDATE_EMAIL)) {
                $email = $_POST['txtEmail'];
                $password = $_POST['txtPass'];
                echo "Email: $email Password: $password<br>";
            } else
                echo 'Email is not valid.';
        }
        ?>
        <br>
        <form method="post" action="">
            <fieldset>
                <legend>Comments</legend>
                <label for="email">Email: </label>
                <input type="text" name="email" value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>" /><br />
                <textarea rows="4" cols="50" name="comment">Comment</textarea><br />
                <label for="">Click to Confirm: </label>
                <input type="checkbox" name="chkConfirm" value="agree"><br />
                <input type="submit" value="Submit" name="commentSubmit" />
                <input type="reset" value="Clear" />
            </fieldset>
        </form>
        <?php
        if (isset($_POST['commentSubmit'])) {
            if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                $email2 = $_POST['email'];
                $comment = $_POST['comment'];
                if (isset($_POST['chkConfirm'])) {
                    $confirm = 'Agreed';
                } else {
                    $confirm = 'Not Agreed';
                }
                echo "Email: $email2<br>Comments: $comment<br>Confirm: $confirm<br>";
            } else
                echo 'Email is invalid.';
        }
        ?>
        <h2>Tax Calculator</h2>
        <form method="post" action="">
            <fieldset>
                <legend>Without TAX calculator</legend>
                <label for="tax">After Tax Price</label>
                <input type="text" name="taxPrice" value="<?php if (isset($_POST['taxPrice'])) echo $_POST['taxPrice']; ?>">
                <label for="rate">Tax Rate</label>
                <input type="text" name="taxRate" value="<?php if (isset($_POST['taxRate'])) echo $_POST['taxRate']; ?>">
                <input type="submit" value="Submit" name="taxSubmit">
                <input type="reset" value="Clear">
            </fieldset>
            <?php
            if (isset($_POST['taxSubmit'])) {
                if (!empty($_POST['taxPrice'] || !empty($_POST['taxRate']))) {
                    if (!preg_match('/^[0-9]+\.[0-9]{2}/', $_POST["taxPrice"]))
                        echo "Please enter the price in the format 9.99";
                    elseif (!filter_var($_POST['taxRate'], FILTER_VALIDATE_INT))
                        echo "Please enter a whole number for tax rate";
                    else {
                        $taxPrice = $_POST['taxPrice'];
                        $taxRate = $_POST['taxRate'];
                        $beforeTax = (100 * $taxPrice) / (100 + $taxRate);
                        echo "<h5>Price before tax = £" . number_format($beforeTax, 2);
                    }
                } else echo "All Fields Required";
            }
            ?>
        </form>
        <h1>Passing Data Appended to an URL</h1>
<h2>Pick a category</h2>
<a href="watWk5.php?cat=films">Films</a>
<a href=" watWk5.php?cat=books">Books</a>
<a href=" watWk5.php?cat=music">Music</a>
<?php if(isset($_GET['cat'])) echo "<br/>You clicked ".$_GET['cat'];?>
    </section>
    <footer>
        <small> <a href="../watIndex.html">Home</a></small>
    </footer>
</body>

</html>
