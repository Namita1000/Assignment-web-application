<?php
//Set up the database access credentials
$hostname = 'localhost';
$username = 'Namita'; //your standard uni id
$password = 'abc'; // the password found on the W: drive
$databaseName = 'dep'; //the name of the db you are using on phpMyAdmin
$connection = mysqli_connect($hostname, $username, $password, $databaseName) or
exit("Unable to connect to database!");
?>