<!DOCTYPE html>
<html lang="en">
 <head>
 <title>Web Applications and Technologies </title>
 <link type="text/css" rel="stylesheet" href="main.css" />
 </head>
 <body><header>
 <h1>Student Name and ID</h1>
 </header>
 <nav>
 <ul>
 <li>Week 1
 <ol>
 <li><a href="index.html" alt="Website">HTML/CSS Recap exercise</a></li>
 </ol>
 </li>
 <li>Week 2
 <ol>
 <li>Lab Team (Draft)
 <ul>
 <li><a href="Image/Myntra.png">
Draft Mindmap
</a></li>
 <li><a href="Image/StructureChart.png">Draft Structure Chart</a></li>
 <li><a href="Image/clothes.png" "width =200px">Draft Wireframe</a></li>
 </ul>
 </li>
 <li>Lab Individual
 <ul>
 <li><a href="Image/HotelMindmap.png">Mindmap</a></li>
 <li><a href="Image/HotelStructure.png">Structure Chart</a></li>
 <li><a href="Image/HotelWireframe.png">Wireframe</a></li>
 </ul>
 </li>
 <li><a href="test.php">PHP Test Page</a></li>
 </li>
 </ol>
 </li>
 <li>Week 3
 <ol>
 <li><a href=#>Evaluation Notes</a></li>
 <li><a href="PHPFundamental/watWk3.php">PHP Fundamentals</a></li>
 </ol>
 </li>
 <li>Week 4
 <ol>
 <li><a href="watWk4.php">More Fundamentals of PHP</a></li>
 </ol>
 </li>
 <li>Week 5
 <ol>
 <li><a href="watWk5.php">PHP Forms</a></li>
 </ol>
 </li>
 <li>Week 6
 <ol>
 <li><a href="watWk6.php">PHP Queries</a></li>
 </ol>
 </li>
 <li>Assignment
 <ul>
 <li><a href=#>Assignment Mindmap</a></li>
 <li><a href=#>Assignment Structure Chart</a></li>
 <li><a href=#>Assignment Wireframe</a></li>
 </ul>
 <li>Week 8
 <ol>
 <li><a href=#>PHP CRUD</a></li>
 </ol>
 </li>
 <li>Week 9
 <ol>
 <li><a href=#>PHP Authentication</a></li>
 </ol>
 </li>
 <li>Web Site
 <ol>
 <li><a href=#>Live site</a></li>
 <li><a href=#>Source Code Zipped</a></li>
 </ol>
 </li>
 </ul>
 </nav>
 <section id="container">
 <p>You can style this page in any way that you wish, you should
 add further links as you see appropriate. You should put this page on the
server such that this page becomes the home page for the module.
 </p>
 </section>
 <footer>
 <small>My Footer Information</small>
 </footer>
 </body>
</html>
