<!DOCTYPE html>
<html lang="en">
 <head>
 <title>Web Applications and Technologies</title>
 <link type="text/css" rel="stylesheet" href="main.css" />
 </head>
 <body>
 <header>
 <h1>Paul Doney C123457</h1>
 </header>

 <section id="container">
 <h1>Further Fundamentals of PHP</h1>
 <?php
 echo "<h2>Arrays</h2>";
        echo "<h3>Simple Arrays</h3>";

        $products = array("t-shirt", "cap", "mug");
        print_r($products);
        echo "<br>";

        $products[1] = "shirt";
        print_r($products);
        echo "<br>";

        array_push($products, "skirt");
        print_r($products);

        echo "Items in my products array";
        echo "The item at index[2] is: " . $products[2] . "<br>";
        echo "The item at index[3] is: " . $products[3] . "<br>";

        $customer = array(12, "Sarah", 23, 'F');


        $customer = array(
            'CustID' => 12,
            'CustName' => 'Sarah',
            'CustAge' => 23,
            'CustGender' => 'F'
        );


        print_r($customer);
        echo "<br>";

        $customer['CustAge'] = 22;
        $customer['CustEmail'] = "sarah@gmail.com";
        print_r($customer);

        echo "<br>" . "Items in my customer array" . "<br>";
        echo "The item at index[CustName] is: " . $customer['CustName'] . "<br>";
        echo "The item at index[CustEmail] is: " . $customer['CustEmail'] . "<br>";


        echo "<h2>Multidimensional Array</h2>";
        $stock = array("id1" => array("description" => "t-shirt", "price" => 9.99, "stock" => 100, "colour" => array("blue", "green", "red")), "id2" => array("description" => "cap", "price" => 4.99, "stock" => 50, "colour" => array("blue", "black", "grey")), "id3" => array("description" => "mug", "price" => 6.99, "stock" => 30, "colour" => array("yellow", "green", "pink")));
        print_r($stock);

        echo "<h3>Multidimensional Associative Arrays</h3>";
        echo "<p>This is my order</p>";
        echo "<p>" . $stock["id1"]["colour"][1] . " " . $stock["id1"]["description"] . "</p>";
        echo "<p>" . "Price: " . "£" . $stock["id1"]["price"] . "</p>";

        echo "<p>" . $stock["id2"]["colour"][2] . " " . $stock["id2"]["description"] . "</p>";
        echo "<p>" . "Price: " . "£" . $stock["id2"]["price"] . "</p>";

        echo "<h2>Loop</h2>";
        echo "<h3>While Loop</h3>";
        $counter = 1;

        while ($counter < 6) {
            echo 'Count: ' . $counter . '<br />';
            $counter++;
        }

        $counter = 1;
        $shirt_price = 9.99;

        while ($counter <= 10) {
            $total_shirt_price = $counter * $shirt_price;
            echo $counter . " - " . $total_shirt_price . "<br>";
            $counter++;
        }


        $counter = 1;
        echo '<table border="1">';
        echo "<tr><th>Quality</th><th>Price</th></tr>";
        while ($counter <= 10) {
            $total_shirt_price = $counter * $shirt_price;
            echo "<tr>" . "<td>" . $counter . "</td>" . "<td>" . $total_shirt_price . "</td></tr>";
            $counter++;
        }
        echo "</table>";

        echo "<h3>For Loops</h3>";
        $names = array("Peter", "Kat", "Laura", "Ali", "Popacatapetal");

        for ($i = 0; $i < 5; ++$i) {
            echo $names[$i] . "<br>";
        }

        echo "<h3>Foreach Loops</h3>";
        $names = array(
            "c123456" => "Peter",
            "c654321" => "Kat",
            "c987654" => "Laura",
            "c654987" => "Ali",
            "c765984" => "Popacatapetal"
        );

        foreach ($names as $id => $name) {
            echo "Name: " . $name . " ID: " . $id . "<br>";
        }

        $city = array('Peter' => 'LEEDS', 'Kat' => 'bradford', 'Laura' => 'wakeFIeld');
        print_r($city);
        echo "<br>";

        foreach ($city as $name => $c) {
            $c = strtolower($c);
            $c = ucfirst($c);
            $city[$name] = $c;
        }
        print_r($city);

?>
 </section>
 <footer>
 <small> <a href="../watIndex.html">Home</a></small>
 </footer>
 </body>
</html>