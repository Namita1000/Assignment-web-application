<?php
//Make connection to database
include 'connection.php';

//(a)Gather from $_POST[]all the data submitted and store in variables

$first_name = $_POST["firstname"];
$last_name = $_POST["lastname"];
$email = $_POST["email"];
$password = $_POST["password"];
$gender = $_POST["gender"];
$age = $_POST["age"];
$gender = $_POST["gender"];
$age = $_POST["age"];

$query = "INSERT INTO `customer` (`FirstName`, `LastName`, `Email`, `Password`, `Gender`, `Age`) VALUES ('$first_name', '$last_name', '$email', '$password', '$gender', '$age')";
mysqli_query($connection, $query);

exit();