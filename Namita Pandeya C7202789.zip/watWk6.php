<!DOCTYPE html>
<html>
<head>
	<title></title>
	  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Customer Details</title>
</head>
<body>

		<p><strong>Enter customer details:</strong></p>
    <form action="insertRecord.php" method="post">
        <div>
            First Name: <input type="text" name="firstname">
        </div><br>
        <div>
            Surname: <input type="text" name="lastname">
            </div><br>
        <div>
            Email: <input type="email" name="email">
        </div><br>
        <div>
            Password: <input type="password" name="password">
        </div><br>
        <div>
            Gender: <select name="gender" id="">
            	<option value="M">Male</option>
                <option value="F">Female</option>
            </select>
        </div><br>
        <div>
            Age: <input type="number" name="age">
        </div><br>
        <input type="submit" value="Submit">
	</form>
<?php
include "selectRecord.php";
?>
</body>
</html>